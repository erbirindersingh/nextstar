@section('sidebar')
<div class="sidebar">
	<h3>Sidebar</h3>
	This is a sidebar
	@show
</div>