<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title>Whoozl</title>
		<link rel="stylesheet" href="css/app.css">
	</head>
	<body>
		<?php echo $__env->make('inc.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		<div class="wrapper">
			<div class="row">
				<div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
					<?php echo $__env->make('inc.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
				</div>
				<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
					<?php echo $__env->yieldContent('content'); ?>
				</div>
				<div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
					<?php echo $__env->make('inc.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
				</div>
			</div>
		</div>
	</body>
</html><?php /**PATH D:\xampp\htdocs\whoozl\resources\views/layouts/app.blade.php ENDPATH**/ ?>