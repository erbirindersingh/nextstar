<?php $__env->startSection('sidebar'); ?>
<div class="sidebar">
	<h3>Sidebar</h3>
	This is a sidebar
	<?php echo $__env->yieldSection(); ?>
</div><?php /**PATH D:\xampp\htdocs\whoozl\resources\views/inc/sidebar.blade.php ENDPATH**/ ?>